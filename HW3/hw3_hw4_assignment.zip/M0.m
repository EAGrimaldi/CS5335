% Output: q -> 1x4 vector of joint angles

function q = M0()
    q = [0 -pi/4 0 -pi/4];
end